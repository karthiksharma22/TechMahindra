package com.app.model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}