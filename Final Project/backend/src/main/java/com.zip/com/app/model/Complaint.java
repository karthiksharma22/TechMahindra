package com.app.model;

public class Complaint {

}
